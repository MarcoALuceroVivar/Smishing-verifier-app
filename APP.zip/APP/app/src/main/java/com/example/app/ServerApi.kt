package com.example.app

import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

data class SmishingRequestBody(val message: String)

data class SmishingResponse(
    @SerializedName("Verdict")
    val verdict: String
)

interface ServerApi {
    @POST("/predict")
    fun predictSmishing(@Body requestBody: SmishingRequestBody): Call<SmishingResponse>
}