package com.example.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.app.ui.theme.APPTheme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {

    private lateinit var serverApi: ServerApi
    private var sender by mutableStateOf("No new messages")
    private var message by mutableStateOf("")
    private var verdict by mutableStateOf("")

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.app.SMS_RECEIVED") {
                val receivedSender = intent.getStringExtra("sender") ?: "Unknown"
                val receivedMessage = intent.getStringExtra("message") ?: ""
                sender = receivedSender
                message = receivedMessage
                predictSmishing(receivedMessage, receivedSender)
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                // Permission is granted. Continue the action or workflow in your app.
            } else {
                // Permission denied.
            }
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createNotificationChannel()
        requestNotificationPermission()

        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.106.84.119:5000")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        serverApi = retrofit.create(ServerApi::class.java)

        registerReceiver(smsReceiver, IntentFilter("com.example.app.SMS_RECEIVED"), RECEIVER_EXPORTED)

        setContent {
            APPTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SmsDisplay(sender, message, verdict)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(smsReceiver)
    }

    private fun predictSmishing(message: String, sender: String) {
        val requestBody = SmishingRequestBody(message)
        serverApi.predictSmishing(requestBody).enqueue(object : Callback<SmishingResponse> {
            override fun onResponse(call: Call<SmishingResponse>, response: Response<SmishingResponse>) {
                if (response.isSuccessful) {
                    val currentVerdict = response.body()?.verdict ?: "Error"
                    verdict = currentVerdict
                    if (currentVerdict.equals("spam", ignoreCase = true)) {
                        showSpamNotification(sender, message)
                    }
                } else {
                    verdict = "Error: ${response.code()}"
                }
            }

            override fun onFailure(call: Call<SmishingResponse>, t: Throwable) {
                verdict = "Failure: ${t.message}"
            }
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Smishing Alerts"
            val descriptionText = "Notifications for potential smishing attacks"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("SMISHING_ALERT_CHANNEL", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    // You can use the API that requires the permission.
                }
                else -> {
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }

    private fun showSpamNotification(sender: String, message: String) {
        val builder = NotificationCompat.Builder(this, "SMISHING_ALERT_CHANNEL")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Warning: Potential Smishing Attack!")
            .setContentText("From: $sender")
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)

        with(NotificationManagerCompat.from(this)) {
            if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return
            }
            notify(1, builder.build())
        }
    }
}

@Composable
fun SmsDisplay(sender: String, message: String, verdict: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Sender: $sender")
        Text(text = "Message: $message")
        Text(text = "Verdict: $verdict")
    }
}
