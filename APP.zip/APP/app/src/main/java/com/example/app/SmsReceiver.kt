package com.example.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages: Array<SmsMessage> = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (smsMessage in messages) {
                val messageBody = smsMessage.messageBody
                val sender = smsMessage.displayOriginatingAddress

                // Pass the message to the MainActivity
                val broadcastIntent = Intent("com.example.app.SMS_RECEIVED")
                broadcastIntent.putExtra("message", messageBody)
                broadcastIntent.putExtra("sender", sender)
                context.sendBroadcast(broadcastIntent)
            }
        }
    }
}