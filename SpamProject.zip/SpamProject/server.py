from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

# Load the trained model
try:
    model = joblib.load('spam_model.pkl')
    print("Model loaded successfully.")
except:
    print("Error: 'spam_model.pkl' not found. Run train_model.py first.")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    message = data.get('message', '')
    
    # Predict
    prediction = model.predict([message])[0]
    
    # Log to console
    print(f"Received: '{message}' -> Verdict: {prediction}")
    return jsonify({'Verdict': prediction})

if __name__ == '__main__':
    # host='0.0.0.0' is CRITICAL. 
    # It tells the server to listen on all public IPs, not just local ones.
    app.run(host='0.0.0.0', port=5000)