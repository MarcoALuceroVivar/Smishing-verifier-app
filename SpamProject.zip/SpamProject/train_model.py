import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import joblib

# 1. Create dummy data for demonstration
# (In a real scenario, you would load 'SMSSpamCollection' here)
data = {
    'message': [
        "Win a free iPhone now! Click here", 
        "Your bank account is compromised, login to secure", 
        "Hey, are we still meeting for lunch?", 
        "Mom called, call her back", 
        "URGENT! You have won cash. Claim now at bit.ly/fake",
        "Meeting reminder for tomorrow 10 AM",
        "Free entry in 2 a wkly comp to win FA Cup final tkts",
        "I love you, see you later"
    ],
    'label': ['spam', 'spam', 'ham', 'ham', 'spam', 'ham', 'spam', 'ham']
}
df = pd.DataFrame(data)

# 2. Build the Pipeline
model = Pipeline([
    ('vectorizer', CountVectorizer()),
    ('classifier', MultinomialNB())
])

# 3. Train
model.fit(df['message'], df['label'])

# 4. Save
joblib.dump(model, 'spam_model.pkl')
print("Model trained and saved as 'spam_model.pkl'!")